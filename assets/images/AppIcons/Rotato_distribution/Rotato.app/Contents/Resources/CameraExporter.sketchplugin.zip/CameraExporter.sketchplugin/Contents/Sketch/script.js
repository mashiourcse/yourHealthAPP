var sketch = require('sketch/dom')
var settings = require('sketch/settings')

var onTestRun = function(context) {
    log("Running test")
    onRun(context, true)
}

var onSelectionChanged = function(context) {
    log("onSelectionChanged")
    // do a check if we are updating right now
    updateMirror(context)
}

var testState = function(context){
    log("upd:Setting state to 1")
    
}

var onUpdateMirror = function(context) {
    log("upd: AUTO, state ")
    updateMirror(context)
}

var updateMirror = function(context) {
    log("upd: MAN, state ")
    var layer
    log("updateMirror")
    if (!context.selection) {
        log("no context selection, using newSelection");
        layer =context.actionContext.document.selectedLayers().layers()[0]
    } else {
        layer = context.selection[0];
    }
    
//    if (context.selection.count() == 0) {
//        log("Selection count 0, no can do")
//        context.document.showMessage('Please select an artboard or a layer in one.');
//        return;
//    }
    
    var artboard = getContainingArtboard(layer);
    
    log("Got the artboard. It is " + artboard.name())
    
    var file_path = tempFolder(context)
    
    var sketch = require('sketch/dom')
    sketch.export(artboard, {
                  formats: "png",
                  scales: "3", // also change filename, plez
                  output: file_path
                  })
    
    var outputFile = file_path + "/" + artboard.name() + "@3x.png"
    log("output file is at " + outputFile)
    
    log("Opening rotato")
    var opened = [[NSWorkspace sharedWorkspace] openFile:outputFile withApplication:"Rotato" andDeactivate:false]
    log("opened : " + opened)
}


/**
 * Returns true if the given layer is an artboard-like object (i.e. an artboard
 * or a symbol master).
 */
 function isArtboard(layer) {
    return layer instanceof MSArtboardGroup || layer instanceof MSSymbolMaster;
}

/**
 * Returns the artboard containing the given layer, null if the layer isn't
 * contained within an artboard, or the layer if it is itself an artboard.
 */
 function getContainingArtboard(layer) {
    while (layer && !isArtboard(layer)) {
        layer = layer.parentGroup();
    }
    
    return layer;
}


var onRun = function(context, isTest) {
  log("onRun");
    
    context.document.showMessage("Preparing artboard for Rotato...");
  
    var doc = context.document;
    
    var artboard = context.selection[0];
    
    if(!is_artboard(artboard)) {
        log("it's not an artboard, leaving")
        return
    }
    
    let artboardWidth = artboard.frame().width()
    let artboardHeight = artboard.frame().height()
    
    log("artboard: " + artboard + " of width " + artboardWidth)
    
    var topLevelLayers = artboard.children()
//    var file_path = "/Users/mortenjust/Downloads/camera"
    var file_path = tempFolder(context)
    
    log("There are " + topLevelLayers.count() + " layers in total")
    
    for(var i = 0; i < topLevelLayers.count(); i++) {
        var s = topLevelLayers[i]; // s=layer
        
        // don't take this layer if not child of artboard, but we want the artboard itself
        if(!is_artboard(s.parentGroup()) && !is_artboard(s) ) {continue}
        
        var visibleIndex = artboard.indexOfLayer(s)
        
        var f = s.frame()
        
        var x = f.x()
        var y = f.y()
        var w = f.width()
        var h = f.height()
        

        var sep = "🔠" // least used emoji on twitter
        var frameString = x + sep + y + sep + w + sep + h
        
        
        // set name
        var sName = s.name() + sep + frameString;
        
        log("sname:" + sName)
        
        
        var fileNames = [];
        
        // wrap s in a group. Donwork
//        c.name = c.name().replace("/", "%")
//        var sketchLayer = sketch.fromNative(s)
//        var group = new sketch.Group({
//                                     name: sketchLayer.name,
//                                     layers: [sketchLayer],
//                                     parent: sketchLayer.parent
//                                     })
        
        var c = s.duplicate();
        c.exportOptions().removeAllExportFormats();
        var exportOption = c.exportOptions().addExportFormat();
        exportOption.setScale(5); // if you change this, also change the value in the SketchArtboard class
        exportOption.setName("@5x");
        
        // get artboard bg color
        var artboardBackground = ""
        if(artboard.hasBackgroundColor){
            artboardBackground = getBackgroundColor(artboard)
        } else {
            artboardBackground = "#000000"
        }
        
        var fileName = file_path + "/"
        if(is_artboard(s)) {
            fileName = fileName + "Artboard.png"
        } else {
            fileName = fileName + sName + sep + artboardWidth + sep + artboardHeight + sep + visibleIndex + sep + artboardBackground + sep + ".png";
        }
        
        fileNames.push(fileName);
        
        var slices = MSExportRequest.exportRequestsFromExportableLayer(c);
        for (var j=0; j < slices.count(); j++) {
            [doc saveArtboardOrSlice:slices[j] toFile:fileNames[j]];
        }
        c.removeFromParent();
    }
    
    var appToLaunch = ""
    var rotatoToLaunch = ""
    if (isTest) {
        appToLaunch = "Design Camera Debug" // previously sketchpreptest
        rotatoToLaunch = "Rotato Debug"
    } else {
        appToLaunch = "Design Camera"
        rotatoToLaunch = "Rotato"
    }
    
    log("apptolaunch:" + appToLaunch)
    log("Done running. Opening the app with ##folder: "+file_path)
    
    [[NSWorkspace sharedWorkspace] openFile:file_path withApplication:appToLaunch andDeactivate:true]
    [[NSWorkspace sharedWorkspace] openFile:file_path withApplication:rotatoToLaunch andDeactivate:true]
}

function getBackgroundColor(artboard){
    return artboard.backgroundColor().immutableModelObject().hexValue()
}

var tempFolder = function(context) {
    doc = context.document
    globallyUniqueString = [[NSProcessInfo processInfo] globallyUniqueString];
    tempDirectoryPath = NSTemporaryDirectory()
    tempDirectoryPath = [tempDirectoryPath stringByAppendingPathComponent:globallyUniqueString];
//    var name = [doc displayName].replace(/\.sketch$/, '') + 'Design-Camera';
//    tempDirectoryPath = [tempDirectoryPath stringByAppendingPathComponent:name];
    tempDirectoryURL = [NSURL fileURLWithPath:tempDirectoryPath isDirectory:true];
    [[NSFileManager defaultManager] createDirectoryAtURL:tempDirectoryURL withIntermediateDirectories:true attributes:nil error:nil];
    return tempDirectoryPath;
}

var onStartup = function(context) {
  log("onStartup");
}
var onOpenDocument = function(context) {
  
}
var onSelectionChanged = function(context) {
//  context.actionContext.document.showMessage("onSelectionChanged");
}

function is_artboard(layer) {
    return [layer isMemberOfClass:[MSArtboardGroup class]]
}


// TODO: Find out if the user has selected the artboard or not
// https://medium.com/@marianomike/the-beginners-guide-to-writing-sketch-plugins-part-5-the-mslayer-class-1868c5b6e1e8
//
//function is_group(layer) {
//    return [layer isMemberOfClass:[MSLayerGroup class]] || [layer isMemberOfClass:[MSArtboardGroup class]]
//}
